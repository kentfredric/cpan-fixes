#ifndef MINIZ_H_
#define MINIZ_H_

#define MINIZ_HEADER_FILE_ONLY
#include "miniz.c"

#endif
