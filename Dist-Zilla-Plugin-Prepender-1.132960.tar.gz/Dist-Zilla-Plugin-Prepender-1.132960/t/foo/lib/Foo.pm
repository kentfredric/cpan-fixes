#
# This file is part of Dist-Zilla-Plugin-Prepender
#
# This software is copyright (c) 2009 by Jerome Quelin.
#
# This is free software; you can redistribute it and/or modify it under
# the same terms as the Perl 5 programming language system itself.
#
package Foo;
# ABSTRACT: Foo
1;
__END__
